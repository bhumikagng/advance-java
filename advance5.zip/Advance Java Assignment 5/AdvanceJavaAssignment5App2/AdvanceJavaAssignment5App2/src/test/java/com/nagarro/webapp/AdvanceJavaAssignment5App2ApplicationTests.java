package com.nagarro.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvanceJavaAssignment5App2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
