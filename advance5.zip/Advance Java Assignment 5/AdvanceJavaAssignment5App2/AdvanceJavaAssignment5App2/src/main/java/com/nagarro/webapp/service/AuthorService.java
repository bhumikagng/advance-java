package com.nagarro.webapp.service;

import java.util.List;
import com.nagarro.webapp.model.Author;


public interface AuthorService {
	
	public List<Author> listAuthors();

}
