package com.nagarro.webapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AdvanceJavaAssignment5App1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
