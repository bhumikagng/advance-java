package com.nagarro.webapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AdvanceJavaAssignment5App1Application {

	public static void main(String[] args) {
		SpringApplication.run(AdvanceJavaAssignment5App1Application.class, args);
	}

}
